// عناصر DOM
const openModal = document.getElementById("openModal");
const closeModal = document.getElementById("closeModal");
const save = document.getElementById("save");

const modal = document.getElementById("modal");
const usernameInput = document.getElementById("usernameInput");

const usersTable = document.getElementById("usersTable");
const usersCount = document.getElementById("usersCount");

// فتح المودال
openModal.onclick = () => {
    modal.classList.add("active");
    usernameInput.value = "";
    usernameInput.focus();
};

// إغلاق المودال
closeModal.onclick = () => {
    modal.classList.remove("active");
};

// إغلاق عند الضغط بالخلفية
modal.onclick = (e) => {
    if (e.target === modal) {
        modal.classList.remove("active");
    }
};

// إضافة مستخدم
save.onclick = () => {
    const name = usernameInput.value.trim();
    if (name === "") return;

    const newRow = document.createElement("tr");
    const index = usersTable.rows.length + 1;

    newRow.innerHTML = `
        <td>${index}</td>
        <td>${name}</td>
        <td>${name.replace(/ /g, '.').toLowerCase()}@example.com</td>
        <td>Active</td>
    `;

    usersTable.appendChild(newRow);

    usersCount.textContent = usersTable.rows.length;

    modal.classList.remove("active");
};
